package com.estilo.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.text.method.DigitsKeyListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

data class Registro(val codigo: String, val pulgadas: Double, val foto: String?)

class MainActivity : Activity() {

    private val registros = mutableListOf<Registro>()
    private lateinit var lista: LinearLayout
    private lateinit var campoBuscar: EditText
    private lateinit var vacio: TextView
    private var alElegirFoto: ((Uri) -> Unit)? = null
    private val REQ_FOTO = 11
    private val morado = Color.parseColor("#6D28D9")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cargar()
        armarPantalla()
        refrescar()
    }

    // ---------- Utilidades ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun fmt(d: Double): String =
        String.format(Locale.US, "%.2f", d).trimEnd('0').trimEnd('.')

    private fun textoMedida(p: Double) = "${fmt(p)} pulg = ${fmt(p * 2.54)} cm"

    // Acepta 12, 12.5, 12,5, 12 1/2, 3/4
    private fun parsePulgadas(s: String): Double? {
        val limpio = s.replace(',', '.').replace("\"", "").trim()
        if (limpio.isEmpty()) return null
        var total = 0.0
        for (t in limpio.split(Regex("\\s+"))) {
            val v: Double = if (t.contains('/')) {
                val p = t.split('/')
                if (p.size != 2) return null
                val a = p[0].toDoubleOrNull() ?: return null
                val b = p[1].toDoubleOrNull() ?: return null
                if (b == 0.0) return null
                a / b
            } else t.toDoubleOrNull() ?: return null
            total += v
        }
        return if (total > 0) total else null
    }

    private fun EditText.alCambiar(f: () -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { f() }
        })
    }

    private fun boton(texto: String, relleno: Boolean): Button = Button(this).apply {
        text = texto
        isAllCaps = false
        if (relleno) { setBackgroundColor(morado); setTextColor(Color.WHITE) }
    }

    // ---------- Almacenamiento (privado, fuera de la galería) ----------
    private fun archivoDatos() = File(filesDir, "registros.json")
    private fun carpetaFotos() = File(filesDir, "fotos").also { it.mkdirs() }

    private fun cargar() {
        try {
            val f = archivoDatos()
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                registros.add(Registro(o.getString("codigo"), o.getDouble("pulgadas"),
                    if (o.isNull("foto")) null else o.getString("foto")))
            }
        } catch (e: Exception) { toast("No se pudieron leer los datos") }
    }

    private fun guardar() {
        val arr = JSONArray()
        registros.forEach {
            arr.put(JSONObject().put("codigo", it.codigo).put("pulgadas", it.pulgadas)
                .put("foto", it.foto ?: JSONObject.NULL))
        }
        archivoDatos().writeText(arr.toString())
    }

    private fun borrarFoto(nombre: String?) {
        if (nombre != null) File(carpetaFotos(), nombre).delete()
    }

    private fun guardarFoto(uri: Uri): String? = try {
        val lim = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, lim) }
        var s = 1
        while (lim.outWidth / s > 1600 || lim.outHeight / s > 1600) s *= 2
        val op = BitmapFactory.Options().apply { inSampleSize = s }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, op) }
            ?: return null
        val orient = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Exception) { 1 }
        val grados = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (grados != 0f) {
            val m = Matrix(); m.postRotate(grados)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val nombre = "f_${System.currentTimeMillis()}.jpg"
        FileOutputStream(File(carpetaFotos(), nombre)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        nombre
    } catch (e: Exception) { null }

    private fun bitmapDe(nombre: String, max: Int): Bitmap? {
        val f = File(carpetaFotos(), nombre)
        if (!f.exists()) return null
        val lim = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, lim)
        var s = 1
        while (lim.outWidth / s > max || lim.outHeight / s > max) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    // ---------- Pantalla principal ----------
    private fun armarPantalla() {
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        raiz.addView(TextView(this).apply {
            text = "estilo"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            setTypeface(null, Typeface.BOLD)
            setTextColor(morado)
        })

        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        campoBuscar = EditText(this).apply {
            hint = "Buscar código (6 dígitos)"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(6))
        }
        campoBuscar.alCambiar { refrescar() }
        fila.addView(campoBuscar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fila.addView(boton("Buscar", false).apply { setOnClickListener { buscar() } })
        raiz.addView(fila)

        raiz.addView(boton("+ Agregar nuevo dato", true).apply {
            setOnClickListener { formulario(null, null) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        vacio = TextView(this).apply {
            text = "Aún no hay registros."
            setPadding(0, dp(24), 0, 0)
            gravity = Gravity.CENTER
        }
        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        scroll.addView(lista)
        raiz.addView(vacio)
        raiz.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(raiz)
    }

    private fun refrescar() {
        val q = campoBuscar.text.toString().trim()
        lista.removeAllViews()
        val filtrados = registros.filter { it.codigo.contains(q) }.sortedBy { it.codigo }
        vacio.visibility = if (filtrados.isEmpty()) View.VISIBLE else View.GONE
        vacio.text = if (registros.isEmpty()) "Aún no hay registros." else "Sin coincidencias."
        for (r in filtrados) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#F3F0FA")); cornerRadius = dp(12).toFloat()
                }
                setOnClickListener { detalle(r) }
            }
            if (r.foto != null) {
                val bm = bitmapDe(r.foto, 200)
                if (bm != null) fila.addView(ImageView(this).apply {
                    setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP
                }, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(12) })
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = r.codigo
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.BLACK)
            })
            col.addView(TextView(this).apply { text = textoMedida(r.pulgadas) })
            fila.addView(col)
            lista.addView(fila, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) })
        }
    }

    // ---------- Buscar ----------
    private fun buscar() {
        val c = campoBuscar.text.toString().trim()
        if (c.length != 6) { toast("Escribe los 6 dígitos para buscar"); return }
        val r = registros.find { it.codigo == c }
        if (r != null) {
            AlertDialog.Builder(this)
                .setTitle("Ya está registrado")
                .setMessage("Código $c\nMedida: ${textoMedida(r.pulgadas)}")
                .setPositiveButton("Ver") { _, _ -> detalle(r) }
                .setNegativeButton("Cerrar", null).show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("No está registrado")
                .setMessage("El código $c no aparece. ¿Deseas agregarlo?")
                .setPositiveButton("Sí, agregar") { _, _ -> formulario(null, c) }
                .setNegativeButton("No", null).show()
        }
    }

    // ---------- Detalle ----------
    private fun detalle(r: Registro) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        col.addView(TextView(this).apply {
            text = "Medida: ${textoMedida(r.pulgadas)}"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        })
        if (r.foto != null) {
            val bm = bitmapDe(r.foto, 1000)
            if (bm != null) col.addView(ImageView(this).apply {
                setImageBitmap(bm); adjustViewBounds = true
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(12) })
        }
        val sv = ScrollView(this); sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Código ${r.codigo}")
            .setView(sv)
            .setPositiveButton("Editar") { _, _ -> formulario(r, null) }
            .setNegativeButton("Borrar") { _, _ -> confirmarBorrar(r) }
            .setNeutralButton("Cerrar", null).show()
    }

    private fun confirmarBorrar(r: Registro) {
        AlertDialog.Builder(this)
            .setTitle("Borrar registro")
            .setMessage("¿Borrar por completo el código ${r.codigo} y su foto?")
            .setPositiveButton("Borrar") { _, _ ->
                borrarFoto(r.foto)
                registros.removeAll { it === r }
                guardar(); refrescar(); toast("Registro borrado")
            }
            .setNegativeButton("Cancelar", null).show()
    }

    // ---------- Agregar / Editar ----------
    private fun formulario(original: Registro?, codigoInicial: String?) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }

        val c = EditText(this).apply {
            hint = "Código (6 dígitos)"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(6))
            setText(original?.codigo ?: codigoInicial ?: "")
        }
        val m = EditText(this).apply {
            hint = "Medida en pulgadas (ej. 12.5 o 12 1/2)"
            keyListener = DigitsKeyListener.getInstance("0123456789.,/ ")
            if (original != null) setText(fmt(original.pulgadas))
        }
        val cm = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(morado)
        }
        fun actualizarCm() {
            val p = parsePulgadas(m.text.toString())
            cm.text = if (p != null) "= ${fmt(p * 2.54)} cm" else ""
        }
        m.alCambiar { actualizarCm() }
        actualizarCm()

        var fotoActual: String? = original?.foto
        val creadas = mutableListOf<String>()
        val img = ImageView(this).apply { adjustViewBounds = true; maxHeight = dp(220) }
        val btnFoto = boton("📷 Elegir foto (opcional)", false)
        val btnQuitar = boton("Quitar foto", false)
        fun mostrarFoto() {
            val bm = fotoActual?.let { bitmapDe(it, 800) }
            if (bm != null) { img.setImageBitmap(bm); img.visibility = View.VISIBLE; btnQuitar.visibility = View.VISIBLE }
            else { img.visibility = View.GONE; btnQuitar.visibility = View.GONE }
        }
        mostrarFoto()
        btnFoto.setOnClickListener {
            alElegirFoto = { uri ->
                val nombre = guardarFoto(uri)
                if (nombre != null) { creadas.add(nombre); fotoActual = nombre; mostrarFoto() }
                else toast("No se pudo cargar la foto")
            }
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            startActivityForResult(i, REQ_FOTO)
        }
        btnQuitar.setOnClickListener { fotoActual = null; mostrarFoto() }

        col.addView(c); col.addView(m); col.addView(cm)
        col.addView(btnFoto); col.addView(img); col.addView(btnQuitar)
        val sv = ScrollView(this); sv.addView(col)

        var guardado = false
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (original == null) "Nuevo dato" else "Editar registro")
            .setView(sv)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        dlg.setOnDismissListener { if (!guardado) creadas.forEach { borrarFoto(it) } }
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val cod = c.text.toString().trim()
            if (!Regex("\\d{6}").matches(cod)) { toast("El código debe tener 6 dígitos"); return@setOnClickListener }
            val p = parsePulgadas(m.text.toString())
            if (p == null) { toast("Escribe una medida válida en pulgadas"); return@setOnClickListener }
            if (registros.any { it.codigo == cod && it !== original }) {
                toast("Ese código ya está registrado"); return@setOnClickListener
            }
            val nuevo = Registro(cod, p, fotoActual)
            if (original != null) {
                val idx = registros.indexOfFirst { it === original }
                if (idx >= 0) registros[idx] = nuevo else registros.add(nuevo)
                if (original.foto != null && original.foto != fotoActual) borrarFoto(original.foto)
            } else registros.add(nuevo)
            creadas.filter { it != fotoActual }.forEach { borrarFoto(it) }
            guardado = true
            guardar(); refrescar()
            toast("Guardado")
            dlg.dismiss()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FOTO && resultCode == RESULT_OK) {
            data?.data?.let { alElegirFoto?.invoke(it) }
        }
    }
}
